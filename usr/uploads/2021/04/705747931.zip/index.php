<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>苏画 | 每天都是最好的自己!</title>
    <meta name="keywords" content="苏画"><!--为搜索引擎定义关键词-->
    <meta name="description" content="苏画 | 一双发现美的眼睛!"><!--为网页定义描述内容-->
   <meta name="author" content="苏画"> <!--定义网页作者-->
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no minimal-ui"><!--设置自动适应电脑和手机屏幕-->
    <link rel="icon" href="http://sh.suvvs.com/chucun/img/logo/favicon.png" type="image/x-icon"/><!--设置浏览器栏favicon图标-->
    <!--link href="./assets/css/style-main.css" rel="stylesheet"--><!--引入css文件-->
    <link rel="stylesheet" href="//at.alicdn.com/t/font_1092713_76e4zsos4y.css">
    <link rel="stylesheet" type="text/css" href="./assets/css/style-android.css" media="screen and (max-width:770px)"/><!--如果分辨率没有达到770则调用手机的模板-->
<link rel="stylesheet" type="text/css" href="./assets/css/style-main.css" media="screen and (min-width:770px)"/><!--如果分辨率达到770则调用电脑的模板-->
<!--苏画原创-首次开源应用日期:April 20, 2021 | QQ:2517270540-->
<!--Original Su painting-first application date: April 20, 2021-->
  </head>

<body>
    
    

    <!--主体框架-->
<div class="centen">
    <!--左侧边栏-->
    <div class="left">

        <!--左侧logo-->
        <div class="left-logo">
            <img src="./assets/images/logo.png" alt="logo">
        </div>

        <!--左侧标题-->
        <div class="left-bt-title">
            <h1>&nbsp;&nbsp;全部</h1>
        </div>

        <!--左侧图标+标题-->
        <div class="left-tb-title">
            <div class="tb-lan">
                <a href="#" style="background:#316af1">
                <i class="iconfont icon-wangluo"></i>
                </a>
                <b><a href="#">世界</a></b>
            </div>

            
            <div class="tb-lan">
                <a href="#" style="background:#02aaff">
                <i class="iconfont icon-radio-off"></i>
                </a>
                <b><a href="#">游戏</a></b>
            </div>

            <div class="tb-lan">
                <a href="#" style="background:#ffb547">
                <i class="iconfont icon-shandian"></i>
                </a>
                <b><a href="#">创意</a></b>
            </div>

            <div class="tb-lan">
                <a href="#" style="background:#ff4242">
                <i class="iconfont icon-xiaolian"></i>
                </a>
                <b><a href="#">沙雕</a></b>
            </div>


            <div class="tb-lan">
                <a href="#" style="background:#23c4a4">
                <i class="iconfont icon-zhinengpinghengkongzhi"></i>
                </a>
                <b><a href="#">人工智能</a></b>
            </div>


         </div>




            <!--左侧底部版权申明-->
            <div class="left-footer">
                <div class="left-footer-n">
                    © 2021 <a href="#" style="text-decoration:none;color:#454545">苏画</a>. All rights reserved.
                </div>
             </div>

            



        


    


     


    </div>



    <!--右侧内容边栏↓-->
    <div class="right">


        <!--右侧内容列栏↓-->
        <div class="right-lan">

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

        </div>
        <!--右侧内容列栏↑-->









        <!--右侧内容列栏↓-->
        <div class="right-lan">

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">BiliBli</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->


        </div>
        <!--右侧内容列栏↑-->








        <!--右侧内容列栏↓-->
        <div class="right-lan">

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="#" title="#">#</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">#</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->

            <!--右侧内容列栏块↓-->
            <div class="right-lan-kuai">
                <div class="right-lan-kuai-zi">
                    <img src="#" alt="img">
                    <div class="right-lan-kuai-zi-bt">
                        <a href="mailto:2517270540@qq.com" title="给我发邮件">联系邮件</a>
                        </div>
                    <div class="right-lan-kuai-zi-nr">给我发邮件</div>
                    <div class="right-lan-kuai-zi-an">网站</div>
                </div>
            </div>
            <!--右侧内容列栏块↑-->


        </div>
        <!--右侧内容列栏↑-->





    </div>


        
















</div>






<script>
    console.log("%c%c苏画%chttps://suvvs.com", "line-height:28px;", "line-height:28px;padding:4px;background:#2ccbe6;color:#FADFA3;font-size:14px;", "padding:4px 4px 4px 2px;background:#ff146d;color:green;line-height:28px;font-size:12px;");
    </script>



</body>
</html>