<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>苏画 | 一双发现美的眼睛!</title>
    <meta name="keywords" content="苏画">
    <meta name="description" content="sing">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no minimal-ui">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="//at.alicdn.com/t/font_2449445_6wuqlywc51d.css">
    <script type="text/javascript">
    /*
    苏画开发-个人主页拟态UI界面-Q2517270540
    个人博客:suvvs.com
    Date:April 13, 2021
    */
    function stop() {
        return false;
        }
        document.oncontextmenu = stop;
    /*document.oncontextmenu = function(){return false;}*/
    document.onkeydown=function (e){
        var currKey=0,evt=e||window.event;
        currKey=evt.keyCode||evt.which||evt.charCode;
        if (currKey == 123) {
            window.event.cancelBubble = true;
            window.event.returnValue = false;
        }
    }
    </script>
</head>
<!--设置动画-->
<style>
a{transition:all 0.1s linear 0s;}
a:hover{transform: scale(1.2,1.2);cursor: pointer;}

a i{transition:all 0.25s linear 0s;}
a i:hover{transform: scale(1.2,1.2);cursor: pointer;}

button{transition:all 0.25s linear 0s;}
button:hover{transform: scale(1.1,1.1);cursor: pointer;}

img{transition:all 0.25s linear 0s;}
img:hover{transform: scale(1.1,1.1);cursor: pointer;}
</style>

<body>
   <!--主体--> 
  <div class="wrapper">
    <div class="img-area">
      <div class="inner-area">
        <img src="http://q1.qlogo.cn/g?b=qq&nk=2517270540&s=5" alt="苏画" class="xwcms">
      </div>
    </div>
    <div class="icon arrow"><i class="fas fa-arrow-left"></i></div>
    <div class="icon dots"><i class="fas fa-ellipsis-v"></i></div>
    <div class="name">苏画</div>
    <div class="about">一双发现美的眼睛!</div>
    <div class="social-icons">
        
      <a href="#" class="fb" title="一双发现美的眼睛!"><i class="iconfont icon-zuanshi"></i>
      <span style="display:none">个人相册</span></a>
     
      <a href="#" class="twitter" title="花魅云"><i style="display:block;width:100px" class="iconfont icon-diannao" ></i>
      <span style="display:none">花魅云</span></a>
      
      <a href="#" class="insta" title="苏画小店,贩卖心情"><i class="iconfont icon-gouwu"></i>
      <span style="display:none">苏画小店,贩卖心情</span></a>

      <a href="#" class="insta" title="我的微博"><i class="iconfont icon-weibo"></i>
      <span style="display:none">我的微博</span></a><br>
     
      <a href="#" class="yt" title="苏画图床"><i class="iconfont icon-tupian"></i>
      <span style="display:none">苏画图床</span></a>

      <a href="#" class="yt" title="BiliBli"><i class="iconfont icon-bilibili-fill"></i>
      <span style="display:none">哔哩哔哩空间</span></a>
      
      <a href="#" class="yt" title="DeepFaceLab素材网"><i class="iconfont icon-zhinengpinghengkongzhi"></i>
      <span style="display:none">DeepFaceLab素材网</span></a>
      
      <a href="#" class="yt" title="给我发邮件"><i class="iconfont icon-youjian"></i>
      <span style="display:none">给我发邮件</span></a>
    </div>
    
    <div class="buttons">
     <button><a href="#" style="text-decoration:none;color:#000000">网站</a></button>
     <button><a href="#" style="text-decoration:none;color:#000000">相册</a></button>
    </div>
    
    <div class="social-share">
      <div class="row">
        <i class="far fa-heart"></i>
        <i class="icon-2 fas fa-heart"></i>
        <span><?php echo date("Y")."y";?></span>
      </div>
      <div class="row">
        <i class="far fa-comment"></i>
        <i class="icon-2 fas fa-comment"></i>
        <span><?php echo date("m"."."."d")."m";?></span>
      </div>
      <div class="row">
        <i class="fas fa-share"></i>
        <span><?php echo date("H"."."."i")."min";?></span>
      </div>
    </div>

  </div>
  <!--版权声明-->
  <script>
  console.log("%c%c苏画%chttps://suvvs.com", "line-height:28px;", "line-height:28px;padding:4px;background:#2ccbe6;color:#FADFA3;font-size:14px;", "padding:4px 4px 4px 2px;background:#ff146d;color:green;line-height:28px;font-size:12px;");
  </script>
    <div class="footer">
        Copyright &copy; 2021<a class="bg" href="#" target="_blank"> 苏画</a> . All rights reserved.
    </div>
</body>
</html>